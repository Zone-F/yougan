var formidable = require("formidable");
var es6 = require("es6");
var path = require("path");
var fs = require("fs");
var ObjectId = require('mongodb').ObjectId;
var mongoose = require('mongoose');
var db = require("../model/db.js");
var md5 = require("../model/md5");

//注册
exports.doRegist = function (req,res,next) {
    //得到用户填写的东西
    var form = new formidable.IncomingForm();
    form.parse(req, function (err, fields, files) {
        //得到表单之后做的事情
        var username = fields.username;
        var password = fields.password;
        var email = fields.email;
        //查询数据库中是不是有这个人
        db.find("users", {"username": username}, function (err, result) {
            if (err) {
                res.send("-3"); //服务器错误
                return;
            }
            if (result.length != 0) {
                res.send("-1"); //被占用
                return;
            }
            //没有相同的人，就可以执行接下来的代码了：
            //设置md5加密
            password = md5(password);

            //现在可以证明，用户名没有被占用
            db.insertOne("userinfo", {
                "username":username,
                "email":email
                },function (err,result) {

                }
                );
            db.insertOne("users", {
                "username": username,
                "password": password,
                "email":email,
                 "avatar": "moren.jpg"
            }, function (err, result) {
                if (err) {
                    res.send("-3"); //服务器错误
                    return;
                }
                 req.session.login = "1";
                 req.session.username = username;

                res.send("1"); //注册成功，写入session
            })
        });
    });
};
//登录
exports.doLogin = function (req, res, next) {
    //得到用户表单
    var form = new formidable.IncomingForm();
    form.parse(req, function (err, fields, files) {
        //得到表单之后做的事情
        var username = fields.username;
        var password = fields.password;
        var jiamihou = md5(password);
        //查询数据库，看看有没有个这个人
        db.find("users", {"username": username}, function (err, result) {
            if (err) {
                res.send("-5");
                return;
            }
            //没有这个人
            if (result.length == 0) {
                res.send("-1"); //用户名不存在
                return;
            }
            //有的话，进一步看看这个人的密码是否匹配
            if (jiamihou == result[0].password) {
                req.session.login = "1";
                req.session.username = username;
                res.send("1");  //登陆成功
                return;
            } else {
                res.send("-2");  //密码错误
                return;
            }
        });
    });
};
//登出
exports.doLogout = function (req,res,next) {
     req.session.login = false , req.session.login ==  ""
    res.redirect('http://127.0.0.1:3000');
};
//头像上传
exports.doSetavatae = function (req, res, next) {
    //必须保证登陆
    if (req.session.login != "1") {
        res.redirect('http://127.0.0.1:3000/login');
        return;
    }

    var form = new formidable.IncomingForm();
    form.uploadDir = path.normalize(__dirname + "/../avatar");
    form.parse(req, function (err, fields, files) {
        console.log(files);
        var oldpath = files.touxiang.path;
        var newpath = path.normalize(__dirname + "/../avatar") + "/" + req.session.username + ".jpg";
        fs.rename(oldpath, newpath, function (err) {
            if (err) {
                res.send("失败");
                return;
            }
            req.session.avatar = req.session.username + ".jpg";
            db.updateMany("users", {"username": req.session.username}, {
                $set: {"avatar": req.session.avatar}
            }, function (err, results) {
                res.redirect('http://127.0.0.1:3000/user');
            });
            return
        });
    });
};

exports.doWrite = function (req,res,next) {
    //必须保证登陆
    if (req.session.login != "1") {
        res.redirect('http://127.0.0.1:3000/login');
        return;
    }
    var username = req.session.username;
    
    var form = new formidable.IncomingForm();
    form.parse(req,function (err,fields,files) {
        var title = fields.title;
        var body = fields.body;
        var date= new Date();
        var mydata = date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate()/*+' '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds()*/;
        db.insertOne("article",{
            "title" : title,
            "username" : username,
            "body" : body,
            "datatime" : mydata
        },function (err,result) {
            if(err){
                res.send("-3") ;//服务器错误
                return;
            }else {
                res.send("1");
            }
        })
    });
};

exports.changeUsername = function (req,res,next) {
    var form = new formidable.IncomingForm();
    form.uploadDir = path.normalize(__dirname + "/../avatar");

    form.parse(req, function (err, fields, files) {

        var username = fields.username;
        var oldpath = form.uploadDir+'/'+req.session.username+'.jpg';
        var newpath = path.normalize(__dirname + "/../avatar") + "/" + username + ".jpg";


        fs.rename(oldpath, newpath, function (err) {if (err) {res.send("失败");return;}
            db.updateMany("users", {"username": req.session.username}, {$set: {"avatar":username+'.jpg',"username": username}}, function (err, results) {
                    db.updateMany("article", {"username": req.session.username}, {
                        $set: {"username":username}
                    }, function (err, results2) {
                        req.session.username = username;
                        res.send("1");
                    });
                });
        });
    });
};

exports.changeEmail = function (req,res,next) {
    var form = new formidable.IncomingForm();

    form.parse(req, function (err, fields, files) {
        var email = fields.email;
        db.updateMany("users", {"username": req.session.username}, {
            $set: {"email": email}
        }, function (err, results) {
            res.send("1");
        });
        return
    });
};

exports.getArticleById = function (req,res,next) {

    var id= req.query.id;
    var _id = mongoose.Types.ObjectId(id);

    db.find("article", {"_id": _id}, function (err, result) {
        if (err) {
            res.send("文章被删除"); //服务器错误
        }
        res.render('article/article', {
            "login": req.session.login == "1" ? true : false,
            "username": req.session.login == "1" ? req.session.username : "",
            "title":result[0].title,
            "body":result[0].body,
            "datatime":result[0].datatime,
            "author":result[0].username
        });
    });

};