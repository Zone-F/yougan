var formidable = require("formidable");
var es6 = require("es6");
var path = require("path");
var fs = require("fs");
var db = require("../model/db");
var md5 = require("../model/md5");

exports.showIndex = function (req, res, next) {
    //检索数据库，查找此人的头像
    if (req.session.login == "1") {
        //如果登陆了
        var username = req.session.username;
        var login = true;
    } else {
        //没有登陆
        var username = "";  //制定一个空用户名
        var login = false;
    }
    //已经登陆了，那么就要检索数据库，查登陆这个人的头像
    db.find("users", {username: username}, function (err, result) {
        if (result.length == 0) {
            var avatar = "moren.jpg";
        } else {
            var avatar = result[0].avatar;
        }
        res.render("index", {
            "login": login,
            "username": username,
            "avatar": avatar    //登录人的头像
        });
    });
};

exports.showRegist = function (req,res,next) {
    res.render('admin/regist', {
        "login": req.session.login == "1" ? true : false,
        "username": req.session.login == "1" ? req.session.username : ""
    })
};

exports.showLogin = function (req, res, next) {
    res.render("admin/login", {
        "login": req.session.login == "1" ? true : false,
        "username": req.session.login == "1" ? req.session.username : ""
    });
};

exports.showSetavatar = function (req, res, next) {
    //必须保证登陆
    if (req.session.login != "1") {
        res.redirect('http://127.0.0.1:3000/login');
        return;
    }
    res.render("admin/setavatar", {
        "login": true,
        "username": req.session.username
    });
};

exports.showWrite = function (req,res,next) {
    res.render('article/write', {
        "login": req.session.login == "1" ? true : false,
        "username": req.session.login == "1" ? req.session.username : ""
    })
};

exports.getAllarticle = function (req,res,next) {

    var page = parseInt(req.query.page);
    db.find("article",{},{"pageamount":5,"page":page,"sort":{"datetime":-1}},function(err,result){
        res.json({"r":result});
    });
};

exports.showArticlelist = function (req,res,next) {
    res.render('article/articlelist', {
        "login": req.session.login == "1" ? true : false,
        "username": req.session.login == "1" ? req.session.username : "",
    });
};
//得到文章总数用于分页
exports.getArticleamount = function (req,res,next) {
    db.getAllCount("article",function(count){
        res.send(count.toString());
    });
};
//展示用户信息
exports.showUser = function (req,res,next) {
    if (req.session.login != "1") {
        res.redirect('http://127.0.0.1:3000/login');
        return;
    }

        db.find("users",{"username":req.session.username},function (err,result) {
                res.render('admin/user', {
                    "login": req.session.login == "1" ? true : false,
                    "username": req.session.login == "1" ? req.session.username : "",
                    "user":req.session.username,
                    "email":result[0].email,
                    "avatar":result[0].avatar,
                });
        });

};
//得到用户文章总数
exports.getUserArticleAmount = function (req,res,next) {
    db.find("article",{"username":req.session.username},function(err,result){
            res.send(result)
    });
} ;
//分页得到用户文章
exports.getUserArticle = function (req,res,next) {
    var page = parseInt(req.query.page);
    db.find("article",{"username":req.session.username},{"pageamount":5,"page":page,"sort":{"datetime":-1}},function (err,result) {
        res.json({"r":result});
    });
};