/**
 * Created by 村中长相较好的男子 on 2018/1/9.
 */

function getPage(mypage) {
    $(".content-box").html("");
    $.get("/getUserArticle?page="+mypage,function (result) {
        for (var i=0;i<result.r.length;i++){
            $(".content-box").append('<br/><p><a>'+result.r[i].title+'</a> <small class="glyphicon glyphicon-time">'+ result.r[i].datatime+'</small></p>')
        }
        $(".content-box").append('<a class="btn btn-success" href="/write" > 灵感来了挡不住，快扶朕去写作</a>');
        $(".content-box").append('<nav><ul class="pager" id="page-nav">' +
            '<li class="previous"><a href="javascript:void(0)" id="previous-page">上一页</a></li>' +
            '<li class="previous"><a href="javascript:void(0)" id="next-page">下一页</a></li>' +
            '</ul></nav>')
    })
}
$.get("/getUserArticleAmount", function (result) {

    var  amount = result.length;

    $(".head-userinfo").append('<p class="glyphicon glyphicon-heart">你一共写了'+ amount+'篇文章</p>');
    //总页数
    pageamount = Math.ceil(amount / 5);
    //监听
    var mypage=0;
    $("#page-nav").append('<li class="previous"><a href="" id="previous-page">上一页</a></li>');
    $("#page-nav").append('<li class="previous"><a href="" id="next-page">下一页</a></li>');

    $('body').on('click','#previous-page',function () {
        if(mypage == 0){
            mypage=mypage
            $(this).parent().addClass("disabled");
        }else{
            mypage-=1;
            getPage(mypage);
        }
    });

    $('body').on('click','#next-page',function () {
        if(mypage+1 == pageamount){
            $(this).parent().addClass("disabled");
        }else{
            mypage+=1;
            getPage(mypage);
        }
    });

});
//移除，添加active的函数
function activeChange(change) {
    $("#nav-list").children("li").removeClass("active");
    change.parent().addClass("active");
}
// 点击我的文章
$("#getarticle").click(function () {
    //添加active
    activeChange($(this));
    getPage(0);
});
//点击个人信息
$("#userinfo").click(function () {
    window.location.reload();
});
//修改email
$("#change-Email").click(function () {
    $.post("/changeemail",{
        "email" : $("#newEmail").val()
    },function (result) {
        if(result==1){
            alert("修改成功");
            window.location.reload();
        }
    })
});
//修改用户名
$("#changeUsername").click(function () {
    $.post("/changeusername",{
        "username" : $("#newUsername").val()
    },function (result) {
        if(result==1){
            alert("修改成功");
            window.location.reload();
        }
    })
});


