/*导航条JS*/
$(window).scroll(function () {
    if ($(".navbar").offset().top > 50) {$(".navbar-fixed-top").addClass("top-nav");
    }else {$(".navbar-fixed-top").removeClass("top-nav");}
});
$(window).ready(function () {
    if($(window).width()<= 1200){
        /*文章块检测*/
        var a=$("#page-bloke-main").children('div');
        for(var i=a.length;i--;i<=2){
            a[i--].remove()
        }
        /*导航栏*/
        var b=$("#example-navbar-collapse").children('ul:last-child');
        b.css("float","left")
    }
});