/**
 * Created by 村中长相较好的男子 on 2017/12/27.
 */

/*导航条JS*/
$(window).scroll(function () {
    if ($(".navbar").offset().top > 50) {$(".navbar-fixed-top").addClass("top-nav");
    }else {$(".navbar-fixed-top").removeClass("top-nav");}
});
/*随机背景*/
$(function(){
    var videoArr=["v_001","v_002","v_003","v_004","v_005","v_006","v_007","v_008","v_009"];
    var video = parseInt(Math.random()*(videoArr.length));
    var currentVideo = videoArr[video];
    $("#fullVideo").empty().html('<source src="static/webm/'+currentVideo+'.webm" type="video/webm">' +
        '<source src="static/webm/'+currentVideo+'.mp4" type="video/mp4">');
});



