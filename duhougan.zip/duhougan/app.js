var express = require('express');
var app = express();
var ejs = require('ejs');
var route = require('./route/route');
var myDo = require('./route/do');
var session = require('express-session');

//使用session
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true
}));

app.set('view engine','ejs');

//静态文件
app.use('/static',express.static('public'));
app.use("/avatar",express.static("./avatar"));
app.get('/',route.showIndex);
app.get('/regist',route.showRegist);
app.post('/doregist',myDo.doRegist);
app.get('/login',route.showLogin);
app.post('/dologin',myDo.doLogin);
app.get('/setavatar',route.showSetavatar);  //上传头像
app.post('/dosetavatar',myDo.doSetavatae);
app.get('/logout',myDo.doLogout);//退出登录
app.get('/write',route.showWrite);
app.post('/dowrite',myDo.doWrite);
//文章列表及文章展示页面
app.get('/articlelist',route.showArticlelist);    //展示文章列表
app.get('/getallarticle',route.getAllarticle);      //取得全部文章
app.get('/getarticleamount',route.getArticleamount);
app.get('/article',myDo.getArticleById);    //通过ID获取文章
//用户界面
app.get('/user',route.showUser);
app.get('/getUserArticleAmount',route.getUserArticleAmount);
app.get('/getUserArticle',route.getUserArticle);
//用户修改信息
app.post('/changeemail',myDo.changeEmail);
app.post('/changeusername',myDo.changeUsername);


app.listen(3000);